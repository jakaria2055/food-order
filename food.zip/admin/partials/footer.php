<!-- Footer Start -->
<div class="footer">
   <div class="wrapper">
     <p class="text-center">2024 all right reserved,Fooding. Developed by-<a href="#">Jakaria Ahmed</a></p>
   </div>
 </div>
<!-- Footer end -->
  </body>

</html>